//
//  data.swift
//  Collection
//
//  Created by Pulipati Venkata Sai on 09/10/22.
//

import Foundation
struct mallData{
    
    let malls:[String]
    
}
